library no_package_test;

class NoPackageTestFile {

}
