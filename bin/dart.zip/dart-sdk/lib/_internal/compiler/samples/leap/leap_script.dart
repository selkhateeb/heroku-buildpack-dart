class LeapScript {
  final text;
  LeapScript(this.text);

  String get name => "SomeName";
  String get uri => name;
  String get file => "somefile";
}
